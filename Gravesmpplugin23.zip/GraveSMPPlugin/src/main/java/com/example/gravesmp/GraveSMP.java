package com.example.gravesmp;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.WorldInitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.trim.TrimMaterial;
import org.bukkit.inventory.trim.TrimPattern;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public final class GraveSMP extends JavaPlugin implements Listener {
    private static final String KITS_TITLE = ChatColor.DARK_RED + "GraveSMP Kits";
    private static final String STARTER = ChatColor.RED + "Starter Kit";
    private static final String PVP = ChatColor.DARK_RED + "PvP Kit";
    private static final String MINER = ChatColor.GRAY + "Miner Kit";
    private static final String HOMES_TITLE = ChatColor.DARK_RED + "Your Homes";
    private static final String INV_TITLE_PREFIX = ChatColor.DARK_RED + "Inventory: ";

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        for (World world : Bukkit.getWorlds()) {
            world.setGameRuleValue("locatorBar", "false");
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            setupPlayer(player);
        }
        new BukkitRunnable() {
            @Override public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    updateScoreboard(player);
                }
            }
        }.runTaskTimer(this, 20L, 20L);
        new BukkitRunnable() {
            private int colorStep = 0;
            private final TrimMaterial[] rainbow = {
                TrimMaterial.REDSTONE, TrimMaterial.COPPER, TrimMaterial.GOLD,
                TrimMaterial.EMERALD, TrimMaterial.DIAMOND, TrimMaterial.LAPIS,
                TrimMaterial.AMETHYST, TrimMaterial.QUARTZ, TrimMaterial.IRON
            };
            @Override public void run() {
                TrimMaterial material = rainbow[(colorStep++ / 10) % rainbow.length];
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (!getRank(player.getUniqueId()).equals("HELPER")
                        && !getRank(player.getUniqueId()).equals("MODERATOR")
                        && !getRank(player.getUniqueId()).equals("OWNER")
                        && !getRank(player.getUniqueId()).equals("MANAGER")) continue;
                    ItemStack[] armor = player.getInventory().getArmorContents();
                    boolean changed = false;
                    for (int i = 0; i < armor.length; i++) {
                        ItemStack piece = armor[i];
                        if (piece == null || !(piece.getItemMeta() instanceof ArmorMeta meta)) continue;
                        if (!meta.getPersistentDataContainer().has(new NamespacedKey(GraveSMP.this, "helper_rainbow_armor"), PersistentDataType.BYTE)) continue;
                        meta.setTrim(new ArmorTrim(material, TrimPattern.SILENCE));
                        piece.setItemMeta(meta);
                        changed = true;
                    }
                    if (changed) player.getInventory().setArmorContents(armor);
                }
            }
        }.runTaskTimer(this, 1L, 10L);
        getLogger().info("GraveSMP enabled.");
    }

    @Override
    public void onDisable() {
        saveConfig();
    }

    @EventHandler
    public void onLogin(PlayerLoginEvent event) {
        String path = "tempbans." + event.getPlayer().getUniqueId();
        long expires = getConfig().getLong(path + ".expires", 0L);
        if (expires > System.currentTimeMillis()) {
            long remaining = (expires - System.currentTimeMillis()) / 1000L;
            event.disallow(PlayerLoginEvent.Result.KICK_BANNED,
                ChatColor.RED + "You are temporarily banned from GraveSMP.\n"
                + ChatColor.GRAY + "Time remaining: " + formatDuration(remaining)
                + "\n" + ChatColor.GRAY + "Reason: " + getConfig().getString(path + ".reason", "No reason provided"));
        } else if (expires != 0L) {
            getConfig().set(path, null);
            saveConfig();
        }
    }

    @EventHandler
    public void onWorldInit(WorldInitEvent event) {
        event.getWorld().setGameRuleValue("locatorBar", "false");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        setupPlayer(event.getPlayer());
        refreshOnlineCount();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Bukkit.getScheduler().runTask(this, this::refreshOnlineCount);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        String victimPath = "stats." + victim.getUniqueId();
        getConfig().set(victimPath + ".deaths", getConfig().getInt(victimPath + ".deaths", 0) + 1);
        Player killer = victim.getKiller();
        if (killer != null) {
            String killerPath = "stats." + killer.getUniqueId();
            getConfig().set(killerPath + ".kills", getConfig().getInt(killerPath + ".kills", 0) + 1);
            int victimStrength = getConfig().getInt("strength." + victim.getUniqueId(), 0);
            ItemStack lantern = createStrengthLantern(victim, victimStrength);
            victim.getWorld().dropItemNaturally(victim.getLocation(), lantern);
            killer.sendMessage(ChatColor.LIGHT_PURPLE + "A Strength Lantern dropped from " + victim.getName() + ".");
        }
        saveConfig();
        updateAllScoreboards();
    }

    private ItemStack createStrengthLantern(Player victim, int strength) {
        ItemStack item = new ItemStack(Material.SOUL_LANTERN);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "Strength Lantern");
        meta.setLore(Arrays.asList(ChatColor.GRAY + "Soul of " + victim.getName(),
            ChatColor.GRAY + "Strength: " + ChatColor.LIGHT_PURPLE + strength,
            ChatColor.YELLOW + "Right-click to absorb this player's strength."));
        meta.getPersistentDataContainer().set(new NamespacedKey(this, "strength_lantern"), PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(new NamespacedKey(this, "victim_strength"), PersistentDataType.INTEGER, Math.max(0, strength));
        meta.getPersistentDataContainer().set(new NamespacedKey(this, "victim_name"), PersistentDataType.STRING, victim.getName());
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onStrengthLanternUse(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = event.getItem();
        if (item == null || item.getType() != Material.SOUL_LANTERN || !item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();
        if (!meta.getPersistentDataContainer().has(new NamespacedKey(this, "strength_lantern"), PersistentDataType.BYTE)) return;
        event.setCancelled(true);
        int gained = Math.max(0, meta.getPersistentDataContainer().getOrDefault(
            new NamespacedKey(this, "victim_strength"), PersistentDataType.INTEGER, 0));
        String victimName = meta.getPersistentDataContainer().getOrDefault(
            new NamespacedKey(this, "victim_name"), PersistentDataType.STRING, "unknown player");
        Player player = event.getPlayer();
        String path = "strength." + player.getUniqueId();
        int current = getConfig().getInt(path, 0);
        getConfig().set(path, current + gained);
        saveConfig();
        if (item.getAmount() <= 1) {
            if (event.getHand() == org.bukkit.inventory.EquipmentSlot.OFF_HAND) player.getInventory().setItemInOffHand(null);
            else player.getInventory().setItemInMainHand(null);
        } else {
            item.setAmount(item.getAmount() - 1);
        }
        player.sendMessage(ChatColor.LIGHT_PURPLE + "You absorbed " + victimName + "'s Strength Lantern and gained " + gained
            + " strength. Total strength: " + (current + gained) + ".");
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        String rank = getRank(player.getUniqueId());
        String prefix = rankPrefix(rank);
        event.setFormat(prefix + ChatColor.WHITE + player.getName() + ChatColor.DARK_GRAY + " » " + ChatColor.RESET + "%2$s");
    }

    private void setupPlayer(Player player) {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        player.setScoreboard(board);
        setupRankTeam(player);
        updateScoreboard(player);
    }

    private void setupRankTeam(Player player) {
        Scoreboard board = player.getScoreboard();
        String rank = getRank(player.getUniqueId());
        String teamName = switch (rank) {
            case "OWNER" -> "00_owner";
            case "MANAGER" -> "01_manager";
            case "MODERATOR" -> "02_moderator";
            case "HELPER" -> "03_helper";
            case "FLOW" -> "04_flow";
            case "ASH" -> "05_ash";
            default -> "10_member";
        };
        for (Team team : board.getTeams()) {
            if (team.hasEntry(player.getName()) && !team.getName().equals(teamName)) {
                team.removeEntry(player.getName());
            }
        }
        Team team = board.getTeam(teamName);
        if (team == null) {
            team = board.registerNewTeam(teamName);
            team.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.ALWAYS);
        }
        team.setPrefix(rankPrefix(rank));
        team.setSuffix(ChatColor.RESET.toString());
        team.addEntry(player.getName());
    }

    private String getRank(UUID uuid) {
        return getConfig().getString("ranks." + uuid, "MEMBER").toUpperCase(Locale.ROOT);
    }

    private ChatColor rankColor(String rank) {
        return switch (rank) {
            case "OWNER" -> ChatColor.RED;
            case "MANAGER" -> ChatColor.GOLD;
            case "MODERATOR" -> ChatColor.RED;
            case "HELPER" -> ChatColor.YELLOW;
            case "FLOW" -> ChatColor.AQUA;
            case "ASH" -> ChatColor.DARK_GRAY;
            default -> ChatColor.GRAY;
        };
    }

    private String rankPrefix(String rank) {
        String label = switch (rank) {
            case "OWNER" -> "OWNER";
            case "MANAGER" -> "MANAGER";
            case "MODERATOR" -> "MOD";
            case "HELPER" -> "HELPER";
            case "FLOW" -> "FLOW";
            case "ASH" -> "ASH";
            default -> "MEMBER";
        };
        return rankColor(rank) + "[" + label + "] ";
    }

    private void updateScoreboard(Player player) {
        Scoreboard board = player.getScoreboard();
        Objective existing = board.getObjective("gravesmp");
        if (existing != null) {
            existing.unregister();
        }
        Objective objective = board.registerNewObjective("gravesmp", Criteria.DUMMY, ChatColor.RED + "" + ChatColor.BOLD + "GraveSMP");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        String path = "stats." + player.getUniqueId();
        int kills = getConfig().getInt(path + ".kills", 0);
        int deaths = getConfig().getInt(path + ".deaths", 0);
        long joinedAt = getConfig().getLong("playtime." + player.getUniqueId() + ".session-start", System.currentTimeMillis());
        long stored = getConfig().getLong("playtime." + player.getUniqueId() + ".seconds", 0);
        long seconds = stored + Math.max(0, (System.currentTimeMillis() - joinedAt) / 1000);
        long minutes = seconds / 60;
        long hours = minutes / 60;
        String playtime = hours > 0 ? hours + "h " + (minutes % 60) + "m" : minutes + "m";

        objective.getScore(ChatColor.DARK_RED + "━━━━━━━━━━━━").setScore(10);
        objective.getScore(ChatColor.RED + player.getName()).setScore(9);
        objective.getScore(ChatColor.GRAY + "Rank: " + rankColor(getRank(player.getUniqueId())) + getRank(player.getUniqueId())).setScore(8);
        objective.getScore(ChatColor.GRAY + "Playtime: " + ChatColor.WHITE + playtime).setScore(7);
        objective.getScore(ChatColor.DARK_GRAY + " ").setScore(6);
        objective.getScore(ChatColor.RED + "INFO").setScore(5);
        objective.getScore(ChatColor.GRAY + "Kills: " + ChatColor.RED + kills).setScore(4);
        objective.getScore(ChatColor.GRAY + "Deaths: " + ChatColor.RED + deaths).setScore(3);
        objective.getScore(ChatColor.DARK_GRAY + "  ").setScore(2);
        double tps = Bukkit.getTPS()[0];
        String tpsText = String.format(Locale.US, "%.1f", Math.min(20.0, tps));
        objective.getScore(ChatColor.GRAY + "TPS: " + ChatColor.RED + tpsText).setScore(1);
        objective.getScore(ChatColor.GRAY + "Online: " + ChatColor.RED + Bukkit.getOnlinePlayers().size()).setScore(0);
        objective.getScore(ChatColor.DARK_RED + "━━━━━━━━━━━━").setScore(-1);
    }

    private void updateAllScoreboards() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            updateScoreboard(player);
        }
    }

    private void refreshOnlineCount() {
        Bukkit.getScheduler().runTask(this, this::updateAllScoreboards);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);

        if (name.equals("strength")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            int strength = getConfig().getInt("strength." + player.getUniqueId(), 0);
            player.sendMessage(ChatColor.LIGHT_PURPLE + "Your strength: " + ChatColor.WHITE + strength);
            return true;
        }

        if (name.equals("setstrength")) {
            if (!sender.hasPermission("gravesmp.setstrength")) {
                sender.sendMessage(ChatColor.RED + "You don't have permission.");
                return true;
            }
            if (args.length != 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /setstrength <player> <amount>");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "That player must be online.");
                return true;
            }
            int amount;
            try {
                amount = Integer.parseInt(args[1]);
            } catch (NumberFormatException ex) {
                sender.sendMessage(ChatColor.RED + "Amount must be a whole number.");
                return true;
            }
            if (amount < 0 || amount > 1000000) {
                sender.sendMessage(ChatColor.RED + "Amount must be between 0 and 1000000.");
                return true;
            }
            getConfig().set("strength." + target.getUniqueId(), amount);
            saveConfig();
            sender.sendMessage(ChatColor.GREEN + "Set " + target.getName() + "'s strength to " + amount + ".");
            target.sendMessage(ChatColor.LIGHT_PURPLE + "Your strength was set to " + amount + ".");
            return true;
        }

        if (name.equals("givestrength")) {
            if (!sender.hasPermission("gravesmp.givestrength")) {
                sender.sendMessage(ChatColor.RED + "You don't have permission.");
                return true;
            }
            if (args.length != 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /givestrength <player> <amount>");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "That player must be online.");
                return true;
            }
            int amount;
            try {
                amount = Integer.parseInt(args[1]);
            } catch (NumberFormatException ex) {
                sender.sendMessage(ChatColor.RED + "Amount must be a whole number.");
                return true;
            }
            if (amount < 0 || amount > 1000000) {
                sender.sendMessage(ChatColor.RED + "Amount must be between 0 and 1000000.");
                return true;
            }
            String path = "strength." + target.getUniqueId();
            int total = getConfig().getInt(path, 0) + amount;
            getConfig().set(path, total);
            saveConfig();
            sender.sendMessage(ChatColor.GREEN + "Gave " + amount + " strength to " + target.getName() + ". Total: " + total);
            target.sendMessage(ChatColor.LIGHT_PURPLE + "An admin gave you " + amount + " strength. Total: " + total);
            return true;
        }

        if (name.equals("tempban")) {
            if (!sender.hasPermission("gravesmp.tempban")) {
                sender.sendMessage(ChatColor.RED + "You don't have permission.");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /tempban <player> <time> [reason]");
                sender.sendMessage(ChatColor.GRAY + "Examples: 10m, 2h, 1d, 1w");
                return true;
            }
            long duration = parseDuration(args[1]);
            if (duration <= 0L) {
                sender.sendMessage(ChatColor.RED + "Invalid duration. Use formats such as 10m, 2h, 1d, or 1w.");
                return true;
            }
            String targetName = args[0];
            org.bukkit.OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
            if (!target.isOnline() && !target.hasPlayedBefore()) {
                sender.sendMessage(ChatColor.RED + "That player has never joined this server.");
                return true;
            }
            String reason = args.length > 2 ? String.join(" ", Arrays.copyOfRange(args, 2, args.length)) : "No reason provided";
            String path = "tempbans." + target.getUniqueId();
            long expires = System.currentTimeMillis() + duration;
            getConfig().set(path + ".name", targetName);
            getConfig().set(path + ".expires", expires);
            getConfig().set(path + ".reason", reason);
            saveConfig();
            Player onlineTarget = Bukkit.getPlayer(target.getUniqueId());
            if (onlineTarget != null) {
                onlineTarget.kickPlayer(ChatColor.RED + "You are temporarily banned from GraveSMP.\n"
                    + ChatColor.GRAY + "Duration: " + args[1] + "\n"
                    + ChatColor.GRAY + "Reason: " + reason);
            }
            sender.sendMessage(ChatColor.GREEN + "Temporarily banned " + targetName + " for " + args[1] + ".");
            return true;
        }

        if (name.equals("setrank")) {
            if (!sender.hasPermission("gravesmp.setrank")) {
                sender.sendMessage(ChatColor.RED + "You don't have permission.");
                return true;
            }
            if (args.length != 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /setrank <player> <member|ash|flow|helper|moderator|manager|owner>");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "That player must be online.");
                return true;
            }
            String rank = args[1].toUpperCase(Locale.ROOT);
            if (!Arrays.asList("OWNER", "MANAGER", "MODERATOR", "HELPER", "FLOW", "ASH", "MEMBER").contains(rank)) {
                sender.sendMessage(ChatColor.RED + "Ranks: member, ash, flow, helper, moderator, manager, owner.");
                return true;
            }
            getConfig().set("ranks." + target.getUniqueId(), rank);
            saveConfig();
            setupRankTeam(target);
            updateAllScoreboards();
            sender.sendMessage(ChatColor.GREEN + "Set " + target.getName() + "'s rank to " + rank + ".");
            target.sendMessage(ChatColor.GREEN + "Your rank is now " + rank + ".");
            return true;
        }

        if (name.equals("inv")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            if (args.length == 0) {
                player.sendMessage(ChatColor.YELLOW + "Usage: /inv <player> — opens a read-only view of their inventory.");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                player.sendMessage(ChatColor.RED + "That player must be online.");
                return true;
            }
            Inventory view = Bukkit.createInventory(null, 45, INV_TITLE_PREFIX + target.getName());
            for (int slot = 0; slot < 36; slot++) {
                ItemStack item = target.getInventory().getItem(slot);
                if (item != null) view.setItem(slot, item.clone());
            }
            ItemStack offhand = target.getInventory().getItemInOffHand();
            if (offhand != null && offhand.getType() != Material.AIR) view.setItem(40, offhand.clone());
            player.openInventory(view);
            return true;
        }

        if (name.equals("homes")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            openHomes(player);
            return true;
        }

        if (name.equals("claimkit")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            if (args.length != 1) {
                player.sendMessage(ChatColor.RED + "Usage: /claimkit <starter|ash|flow|helper>");
                return true;
            }
            claimKit(player, args[0].toLowerCase(Locale.ROOT));
            return true;
        }

        if (name.equals("kits")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            openKits(player);
            return true;
        }

        if (name.equals("setspawn")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            if (!player.hasPermission("gravesmp.setspawn")) {
                player.sendMessage(ChatColor.RED + "You don't have permission.");
                return true;
            }
            saveLocation("spawn", player.getLocation());
            player.sendMessage(ChatColor.GREEN + "GraveSMP spawn set.");
            return true;
        }

        if (name.equals("spawn")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            Location location = loadLocation("spawn");
            if (location == null) {
                player.sendMessage(ChatColor.RED + "Spawn has not been set yet.");
                return true;
            }
            player.teleport(location);
            player.sendMessage(ChatColor.GREEN + "Teleported to spawn.");
            return true;
        }

        if (name.equals("sethome")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            String homeName = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "home";
            String base = "homes." + player.getUniqueId() + "." + homeName;
            if (!getConfig().contains(base) && countHomes(player) >= maxHomes(player)) {
                player.sendMessage(ChatColor.RED + "Your rank allows " + maxHomes(player) + " homes.");
                return true;
            }
            saveLocation(base, player.getLocation());
            player.sendMessage(ChatColor.GREEN + "Home '" + homeName + "' set.");
            return true;
        }

        if (name.equals("home")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            if (args.length == 0) {
                openHomes(player);
                return true;
            }
            Location location = loadLocation("homes." + player.getUniqueId() + "." + args[0].toLowerCase(Locale.ROOT));
            if (location == null) {
                player.sendMessage(ChatColor.RED + "Home not found. Use /homes to view saved homes.");
                return true;
            }
            player.teleport(location);
            player.sendMessage(ChatColor.GREEN + "Teleported home.");
            return true;
        }

        if (name.equals("string")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            player.getInventory().clear();
            player.getInventory().setArmorContents(new ItemStack[4]);
            player.getInventory().setItemInOffHand(null);
            for (int slot = 0; slot < 36; slot++) {
                player.getInventory().setItem(slot, new ItemStack(Material.STRING, 64));
            }
            player.sendMessage(ChatColor.GREEN + "Your inventory was cleared and filled with string. Your offhand was left empty.");
            return true;
        }

        if (name.equals("echest")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            player.openInventory(player.getEnderChest());
            return true;
        }

        if (name.equals("rtp")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command can only be used in-game.");
                return true;
            }
            World world = player.getWorld();
            if (world.getEnvironment() == World.Environment.THE_END) {
                player.sendMessage(ChatColor.RED + "RTP is disabled in The End. Use it in the Overworld or Nether.");
                return true;
            }
            player.sendMessage(ChatColor.YELLOW + "Finding a safe random location...");
            java.util.Random random = new java.util.Random();
            Location safeLocation = null;
            for (int attempt = 0; attempt < 80; attempt++) {
                int x = random.nextInt(6001) - 3000;
                int z = random.nextInt(6001) - 3000;
                int highestY = world.getHighestBlockYAt(x, z);
                if (highestY <= world.getMinHeight() || highestY + 2 >= world.getMaxHeight()) continue;
                Material ground = world.getBlockAt(x, highestY, z).getType();
                Material feet = world.getBlockAt(x, highestY + 1, z).getType();
                Material head = world.getBlockAt(x, highestY + 2, z).getType();
                if (!ground.isSolid() || ground == Material.LAVA || ground == Material.MAGMA_BLOCK
                    || ground == Material.CACTUS || ground == Material.CAMPFIRE
                    || !feet.isPassable() || !head.isPassable()) continue;
                safeLocation = new Location(world, x + 0.5, highestY + 1, z + 0.5);
                break;
            }
            if (safeLocation == null) {
                player.sendMessage(ChatColor.RED + "Couldn't find a safe location. Try /rtp again.");
                return true;
            }
            player.teleport(safeLocation);
            player.sendMessage(ChatColor.GREEN + "Randomly teleported to " + safeLocation.getBlockX() + ", " + safeLocation.getBlockZ() + ".");
            return true;
        }
        return false;
    }

    private void openKits(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 27, KITS_TITLE);
        inventory.setItem(10, kitIcon(Material.IRON_CHESTPLATE, ChatColor.WHITE + "Starter Kit", "Everyone • 30 minute cooldown"));
        inventory.setItem(12, kitIcon(Material.GOLDEN_APPLE, ChatColor.GRAY + "ASH Kit", "ASH rank • 6 hour cooldown"));
        inventory.setItem(14, kitIcon(Material.DIAMOND_SWORD, ChatColor.AQUA + "FLOW Kit", "Diamond gear • no Thorns • 6 hour cooldown"));
        inventory.setItem(16, kitIcon(Material.SHIELD, ChatColor.YELLOW + "Helper Kit", "Diamond FLOW-style kit for Helper/Moderator"));
        player.openInventory(inventory);
    }

    private void openHomes(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 54, HOMES_TITLE);
        String path = "homes." + player.getUniqueId();
        if (getConfig().isConfigurationSection(path)) {
            for (String home : getConfig().getConfigurationSection(path).getKeys(false)) {
                Location loc = loadLocation(path + "." + home);
                if (loc == null) continue;
                ItemStack icon = new ItemStack(Material.ENDER_PEARL);
                ItemMeta meta = icon.getItemMeta();
                meta.setDisplayName(ChatColor.GREEN + home);
                meta.setLore(Arrays.asList(ChatColor.GRAY + loc.getWorld().getName(), ChatColor.GRAY +
                    loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ(), ChatColor.YELLOW + "Click to teleport"));
                icon.setItemMeta(meta);
                int slot = Math.min(44, inventory.firstEmpty());
                if (slot >= 0) inventory.setItem(slot, icon);
            }
        }
        ItemStack info = new ItemStack(Material.BOOK);
        ItemMeta infoMeta = info.getItemMeta();
        infoMeta.setDisplayName(ChatColor.GOLD + "Your Homes");
        infoMeta.setLore(Arrays.asList(ChatColor.GRAY + "Homes: " + countHomes(player) + "/" + maxHomes(player),
            ChatColor.GRAY + "Use /sethome <name> to save a home", ChatColor.GRAY + "Use /homes to open this menu"));
        info.setItemMeta(infoMeta);
        inventory.setItem(49, info);
        player.openInventory(inventory);
    }

    private int maxHomes(Player player) {
        return switch (getRank(player.getUniqueId())) {
            case "OWNER", "MANAGER" -> 99;
            case "FLOW" -> 12;
            case "ASH" -> 4;
            default -> 1;
        };
    }

    private int countHomes(Player player) {
        String path = "homes." + player.getUniqueId();
        return getConfig().isConfigurationSection(path) ? getConfig().getConfigurationSection(path).getKeys(false).size() : 0;
    }

    private void claimKit(Player player, String kitName) {
        String rank = getRank(player.getUniqueId());
        boolean unlimited = rank.equals("OWNER") || rank.equals("MANAGER");
        boolean eligible = unlimited || switch (kitName) {
            case "starter" -> true;
            case "ash" -> rank.equals("ASH") || rank.equals("FLOW");
            case "flow" -> rank.equals("FLOW");
            case "helper" -> rank.equals("HELPER") || rank.equals("MODERATOR");
            default -> false;
        };
        if (!eligible) {
            player.sendMessage(ChatColor.RED + "Your rank cannot claim that kit.");
            return;
        }
        long cooldown = kitName.equals("starter") ? 30L * 60_000L : 6L * 60L * 60_000L;
        String path = "kit-cooldowns." + player.getUniqueId() + "." + kitName;
        long next = getConfig().getLong(path, 0L);
        if (!unlimited && next > System.currentTimeMillis()) {
            player.sendMessage(ChatColor.RED + "That kit is on cooldown for " + formatDuration((next - System.currentTimeMillis()) / 1000L) + ".");
            return;
        }
        List<ItemStack> items = new ArrayList<>();
        if (kitName.equals("starter")) {
            items.add(new ItemStack(Material.IRON_SWORD)); items.add(new ItemStack(Material.IRON_PICKAXE));
            items.add(new ItemStack(Material.IRON_AXE)); items.add(new ItemStack(Material.IRON_SHOVEL));
            items.add(new ItemStack(Material.SHIELD)); items.add(new ItemStack(Material.COOKED_BEEF, 64));
            items.add(new ItemStack(Material.IRON_HELMET)); items.add(new ItemStack(Material.IRON_CHESTPLATE));
            items.add(new ItemStack(Material.IRON_LEGGINGS)); items.add(new ItemStack(Material.IRON_BOOTS));
        } else if (kitName.equals("ash")) {
            addTrimmedArmor(player, items, Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS, Enchantment.PROTECTION, 2, false, TrimPattern.FLOW, TrimMaterial.LAPIS, false);
            items.add(enchant(new ItemStack(Material.DIAMOND_SWORD), Enchantment.SHARPNESS, 3));
            items.add(new ItemStack(Material.GOLDEN_APPLE, 16)); items.add(new ItemStack(Material.ENCHANTED_GOLDEN_APPLE));
            items.add(new ItemStack(Material.TRIDENT)); items.add(new ItemStack(Material.ANVIL)); items.add(new ItemStack(Material.CRAFTING_TABLE));
        } else {
            boolean helper = kitName.equals("helper");
            TrimPattern armorPattern = helper ? TrimPattern.SILENCE : TrimPattern.FLOW;
            TrimMaterial armorMaterial = helper ? TrimMaterial.REDSTONE : TrimMaterial.REDSTONE;
            addTrimmedArmor(player, items, Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS, Enchantment.PROTECTION, 4, true, armorPattern, armorMaterial, helper);
            ItemStack maxSword = enchant(new ItemStack(Material.DIAMOND_SWORD), Enchantment.SHARPNESS, 5);
            maxSword = enchant(maxSword, Enchantment.UNBREAKING, 3);
            maxSword = enchant(maxSword, Enchantment.MENDING, 1);
            items.add(maxSword);
            ItemStack maxPick = enchant(new ItemStack(Material.DIAMOND_PICKAXE), Enchantment.EFFICIENCY, 5);
            maxPick = enchant(maxPick, Enchantment.UNBREAKING, 3);
            maxPick = enchant(maxPick, Enchantment.MENDING, 1);
            items.add(maxPick);
            ItemStack maxAxe = enchant(new ItemStack(Material.DIAMOND_AXE), Enchantment.EFFICIENCY, 5);
            maxAxe = enchant(maxAxe, Enchantment.UNBREAKING, 3);
            maxAxe = enchant(maxAxe, Enchantment.MENDING, 1);
            items.add(maxAxe);
            ItemStack maxShovel = enchant(new ItemStack(Material.DIAMOND_SHOVEL), Enchantment.EFFICIENCY, 5);
            maxShovel = enchant(maxShovel, Enchantment.UNBREAKING, 3);
            maxShovel = enchant(maxShovel, Enchantment.MENDING, 1);
            items.add(maxShovel);
            items.add(new ItemStack(Material.TOTEM_OF_UNDYING, 2)); items.add(new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 2));
            items.add(new ItemStack(Material.GOLDEN_APPLE, 128)); items.add(new ItemStack(Material.COBWEB, 128));
            items.add(new ItemStack(Material.BREEZE_ROD, 128)); items.add(new ItemStack(Material.ENDER_PEARL, 64));
            items.add(new ItemStack(Material.ANVIL, 4)); items.add(new ItemStack(Material.WATER_BUCKET, 2));
            items.add(new ItemStack(Material.SPLASH_POTION, 16)); items.add(new ItemStack(Material.LINGERING_POTION, 8));
            if (helper) player.sendMessage(ChatColor.YELLOW + "Helper kit claimed.");
        }
        for (ItemStack item : items) {
            if (isArmor(item.getType())) {
                org.bukkit.inventory.PlayerInventory inventory = player.getInventory();
                int slot = armorSlot(item.getType());
                ItemStack[] armor = inventory.getArmorContents();
                ItemStack currentlyWorn = armor[slot];
                if (currentlyWorn == null || currentlyWorn.getType() == Material.AIR) {
                    armor[slot] = item;
                    inventory.setArmorContents(armor);
                    continue;
                }
            }
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
            for (ItemStack remaining : leftover.values()) player.getWorld().dropItemNaturally(player.getLocation(), remaining);
        }
        if (!unlimited) {
            getConfig().set(path, System.currentTimeMillis() + cooldown);
            saveConfig();
        }
        player.sendMessage(ChatColor.GREEN + kitName.toUpperCase(Locale.ROOT) + " kit claimed.");
        player.closeInventory();
    }

    private boolean isArmor(Material material) {
        return material == Material.DIAMOND_HELMET || material == Material.DIAMOND_CHESTPLATE
            || material == Material.DIAMOND_LEGGINGS || material == Material.DIAMOND_BOOTS
            || material == Material.IRON_HELMET || material == Material.IRON_CHESTPLATE
            || material == Material.IRON_LEGGINGS || material == Material.IRON_BOOTS;
    }

    private int armorSlot(Material material) {
        return switch (material) {
            case DIAMOND_BOOTS, IRON_BOOTS -> 0;
            case DIAMOND_LEGGINGS, IRON_LEGGINGS -> 1;
            case DIAMOND_CHESTPLATE, IRON_CHESTPLATE -> 2;
            default -> 3;
        };
    }

    private void addArmor(List<ItemStack> items, Material helmet, Material chest, Material legs, Material boots, Enchantment enchantment, int level, boolean maxed) {
        for (Material material : new Material[]{helmet, chest, legs, boots}) {
            ItemStack item = new ItemStack(material);
            item = enchant(item, enchantment, level);
            if (maxed) {
                item = enchant(item, Enchantment.UNBREAKING, 3);
                item = enchant(item, Enchantment.MENDING, 1);
            }
            items.add(item);
        }
    }

    private void addTrimmedArmor(Player player, List<ItemStack> items, Material helmet, Material chest, Material legs, Material boots,
                                 Enchantment enchantment, int level, boolean maxed, TrimPattern pattern,
                                 TrimMaterial trimMaterial, boolean rainbow) {
        for (Material material : new Material[]{helmet, chest, legs, boots}) {
            ItemStack item = new ItemStack(material);
            item = enchant(item, enchantment, level);
            if (maxed) {
                item = enchant(item, Enchantment.UNBREAKING, 3);
                item = enchant(item, Enchantment.MENDING, 1);
            }
            if (item.getItemMeta() instanceof ArmorMeta meta) {
                meta.setTrim(new ArmorTrim(trimMaterial, pattern));
                if (rainbow) meta.getPersistentDataContainer().set(
                    new NamespacedKey(this, "helper_rainbow_armor"), PersistentDataType.BYTE, (byte) 1);
                item.setItemMeta(meta);
            }
            items.add(item);
        }
    }

    private ItemStack enchant(ItemStack item, Enchantment enchantment, int level) {
        item.addUnsafeEnchantment(enchantment, level);
        return item;
    }

    private ItemStack kitIcon(Material material, String title, String description) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(title);
        meta.setLore(Arrays.asList(ChatColor.GRAY + description, ChatColor.YELLOW + "Click to claim"));
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        String title = event.getView().getTitle();
        if (title.equals(KITS_TITLE)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null) return;
            switch (clicked.getType()) {
                case IRON_CHESTPLATE -> claimKit(player, "starter");
                case GOLDEN_APPLE -> claimKit(player, "ash");
                case DIAMOND_SWORD -> claimKit(player, "flow");
                case SHIELD -> claimKit(player, "helper");
                default -> { }
            }
        } else if (title.equals(HOMES_TITLE)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || clicked.getType() != Material.ENDER_PEARL || !clicked.hasItemMeta()) return;
            String home = ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
            Location loc = loadLocation("homes." + player.getUniqueId() + "." + home);
            if (loc != null) {
                player.closeInventory();
                player.teleport(loc);
                player.sendMessage(ChatColor.GREEN + "Teleported to " + home + ".");
            }
        } else if (title.startsWith(INV_TITLE_PREFIX)) {
            event.setCancelled(true);
        }
    }

    private long parseDuration(String input) {
        try {
            String value = input.toLowerCase(Locale.ROOT);
            if (value.length() < 2) return -1L;
            long amount = Long.parseLong(value.substring(0, value.length() - 1));
            if (amount <= 0L) return -1L;
            long multiplier = switch (value.charAt(value.length() - 1)) {
                case 's' -> 1000L;
                case 'm' -> 60_000L;
                case 'h' -> 3_600_000L;
                case 'd' -> 86_400_000L;
                case 'w' -> 604_800_000L;
                default -> -1L;
            };
            if (multiplier < 0L || amount > Long.MAX_VALUE / multiplier) return -1L;
            return amount * multiplier;
        } catch (NumberFormatException exception) {
            return -1L;
        }
    }

    private String formatDuration(long seconds) {
        if (seconds >= 86400L) return (seconds / 86400L) + "d " + ((seconds % 86400L) / 3600L) + "h";
        if (seconds >= 3600L) return (seconds / 3600L) + "h " + ((seconds % 3600L) / 60L) + "m";
        if (seconds >= 60L) return (seconds / 60L) + "m " + (seconds % 60L) + "s";
        return seconds + "s";
    }

    private void saveLocation(String path, Location location) {
        World world = location.getWorld();
        if (world == null) return;
        getConfig().set(path + ".world", world.getName());
        getConfig().set(path + ".x", location.getX());
        getConfig().set(path + ".y", location.getY());
        getConfig().set(path + ".z", location.getZ());
        getConfig().set(path + ".yaw", location.getYaw());
        getConfig().set(path + ".pitch", location.getPitch());
        saveConfig();
    }

    private Location loadLocation(String path) {
        String worldName = getConfig().getString(path + ".world");
        if (worldName == null) return null;
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world, getConfig().getDouble(path + ".x"), getConfig().getDouble(path + ".y"),
            getConfig().getDouble(path + ".z"), (float) getConfig().getDouble(path + ".yaw"),
            (float) getConfig().getDouble(path + ".pitch"));
    }
}
